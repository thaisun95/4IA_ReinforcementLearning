use rand::{Rng, SeedableRng};
use rand_xoshiro::Xoshiro256PlusPlus;

trait MonteCarloEnv {
    fn state(&self) -> usize;
    fn num_states(&self) -> usize;
    fn num_actions(&self) -> usize;
    fn step(&mut self, a: usize);
    fn score(&self) -> f32;
    fn is_game_over(&self) -> bool;
    fn reset(&mut self);
}

struct LineWorldEnv {
    agent_pos: usize
}

impl MonteCarloEnv for LineWorldEnv {
    fn state(&self) -> usize {
        self.agent_pos
    }

    fn num_states(&self) -> usize {
        5
    }

    fn num_actions(&self) -> usize {
        2
    }

    fn step(&mut self, a: usize) {
        assert!(!self.is_game_over());
        assert!(a < self.num_actions());

        match a {
            0 => self.agent_pos -= 1,
            1 => self.agent_pos += 1,
            _ => unreachable!()
        }
    }

    fn score(&self) -> f32 {
        match self.agent_pos {
            0 => -1f32,
            4 => 1f32,
            1..=3 => 0f32,
            _ => panic!("Invalid agent pos")
        }
    }

    fn is_game_over(&self) -> bool {
        self.agent_pos == 0 || self.agent_pos == 4
    }

    fn reset(&mut self) {
        self.agent_pos = 2;
    }
}

fn q_learning(
    mut env: impl MonteCarloEnv,
    episodes_count: usize,
    epsilon: f32,
    gamma: f32,
    alpha: f32,
    rng: &mut impl Rng,
) -> (Vec<usize>, Vec<Vec<f32>>) {
    let mut q = (0..env.num_states())
        .map(|_s|
            (0..env.num_actions())
                .map(|_a| rng.random_range(-1f32..1f32))
                .collect::<Vec<_>>()
        ).collect::<Vec<_>>();
    
    for _ep_id in 0..episodes_count {
        env.reset();
        let mut s = env.state();
        
        while !env.is_game_over() {
            let a = if rng.random_range(0f32..1f32) <= epsilon {
                rng.random_range(0..env.num_actions())
            } else {
                let mut best_a = 0;
                let mut best_a_score = f32::MIN;
                
                for a in 0..env.num_actions() {
                    if best_a_score <= q[s][a] {
                        best_a = a;
                        best_a_score = q[s][a];
                    }
                }
                
                best_a
            };
            
            let prev_score = env.score();
            env.step(a);
            let r = env.score() - prev_score;
            
            let s_p = env.state();
            if env.is_game_over() {
                for q_s_p_a in &mut q[s_p] {
                    *q_s_p_a = 0f32;
                }
            }
            
            [5, 6, 8, 1, 2, 3].iter().max();
            
            q[s][a] = q[s][a] + 
                alpha * (r + gamma * q[s_p].iter().max_by(|a, b| a.partial_cmp(b).unwrap()).unwrap() - q[s][a]);
        
            s = s_p;
        }
    }
    
    let pi = q.iter()
        .map(|q_s| {
            let mut best_a = 0;
            let mut best_a_score = f32::MIN;

            for (a, &q_s_a) in q_s.iter().enumerate().take(env.num_actions()) {
                if best_a_score <= q_s_a {
                    best_a = a;
                    best_a_score = q_s_a;
                }
            }

            best_a
        }).collect::<Vec<_>>();

    (pi, q)
}


fn main() {
    let env = LineWorldEnv {
        agent_pos: 2
    };
    let (pi, q) = q_learning(
        env,
        1_000_000,
        1f32,
        0.9999f32,
        0.1f32,
        &mut Xoshiro256PlusPlus::from_os_rng()
    );
    
    dbg!(pi);
    dbg!(q);
}
